package kwm.robo;

public class Position {
  //-------------------------------------------------------------
  // identifyPosition() - identifies the startPosition on a desk
  //------------------------------------------------------------- 
  public static void identifyPosition() {
    
  }
  
  //-------------------------------------------------------------
  // positionOnLine() - the robo positions on the line
  //------------------------------------------------------------- 
  public static void positionOnLine() {
    
  }
  
  //-------------------------------------------------------------
  // deskNumber() - identifies the desknumber(1,2 or 3)
  //------------------------------------------------------------- 
  public static void deskNumber() {
    
  }

  //-------------------------------------------------------------
  // redContact() - identifies the number of contacts with the 
  // red line. it is needed to identify if the robo must drive
  // to the next desk
  //------------------------------------------------------------- 
  public static void redContact() {
    
  }
}
